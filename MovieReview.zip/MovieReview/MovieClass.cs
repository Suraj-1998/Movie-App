﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MovieReview
{
    public class MovieClass
    {
        public int movieid { get; set; }
        public string moviename { get; set; }
        public string plot { get; set; }
        public DateTime dor { get; set; }
        public string actors { get; set; }
        public string producer { get; set; }

       

    }
}