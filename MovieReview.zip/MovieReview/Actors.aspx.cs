﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MovieReview
{
    public partial class Actors : System.Web.UI.Page
    {
        DataBaseOperations db = new DataBaseOperations();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadGrid();
            }
        }

        private void LoadGrid()
        {
            List<ActorClass> lst = db.GetAllActors();
            if (lst.Count() > 0)
            {
                GridView1.DataSource = lst;
                GridView1.DataBind();
            }
        }
    }
}