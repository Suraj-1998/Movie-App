﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace MovieReview
{
    
    public class DataBaseOperations
    {
        public string connection = ConfigurationManager.AppSettings["ConnectionString"];

        public List<MovieClass> GetMovies()
        {
            List<MovieClass> lst = new List<MovieClass>();
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = sqlConnection;
                        command.CommandType = CommandType.Text;
                            command.CommandText = "SELECT movieid,moviename,plot,dor,actors,producer FROM movie";
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {

                                MovieClass wk = new MovieClass();
                                wk.movieid = Convert.ToInt32(reader["movieid"]);
                                wk.moviename = Convert.ToString(reader["moviename"]);
                                wk.plot = Convert.ToString(reader["plot"]);
                                wk.dor = Convert.ToDateTime(reader["dor"]);
                                wk.actors = Convert.ToString(reader["actors"]);
                                wk.producer = Convert.ToString(reader["producer"]);
                                lst.Add(wk);

                            }
                        }
                    }
                    sqlConnection.Close();

                }
            }
            catch(Exception e)
            {

            }
            return lst;
        }

        public List<ActorClass> GetAllActors()
        {
            List<ActorClass> lst = new List<ActorClass>();
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = sqlConnection;
                        command.CommandType = CommandType.Text;
                        command.CommandText = "SELECT actorid,actorname,bio,dob,gender  FROM actor";
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {

                                ActorClass wk = new ActorClass();
                                wk.actorid = Convert.ToInt32(reader["actorid"]);
                                wk.actorname = Convert.ToString(reader["actorname"]);
                                wk.bio = Convert.ToString(reader["bio"]);
                                wk.dob = Convert.ToString(reader["dob"]);
                                wk.gender = Convert.ToString(reader["gender"]);
                                lst.Add(wk);

                            }
                        }
                    }
                    sqlConnection.Close();

                }
            }
            catch (Exception e)
            {

            }
            return lst;
        }

        public List<ProducerClass> GetAllProducers()
        {
            List<ProducerClass> lst = new List<ProducerClass>();
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = sqlConnection;
                        command.CommandType = CommandType.Text;
                        command.CommandText = "SELECT producerid,producername,bio,company,dob,gender FROM producer";
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {

                                ProducerClass wk = new ProducerClass();
                                wk.producerid = Convert.ToInt32(reader["producerid"]);
                                wk.producername = Convert.ToString(reader["producername"]);
                                wk.bio = Convert.ToString(reader["bio"]);
                                wk.company = Convert.ToString(reader["company"]);
                                wk.dob = Convert.ToString(reader["dob"]);
                                wk.gender = Convert.ToString(reader["gender"]);
                                lst.Add(wk);

                            }
                        }
                    }
                    sqlConnection.Close();

                }
            }
            catch (Exception e)
            {

            }
            return lst;
        }

        public List<string> GetActors()
        {
            List<string> lst = new List<string>();
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = sqlConnection;
                        command.CommandType = CommandType.Text;
                        command.CommandText = "SELECT actorname FROM actor";
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {

                                lst.Add(Convert.ToString(reader["actorname"]));

                            }
                        }
                    }
                    sqlConnection.Close();

                }
            }
            catch (Exception e)
            {

            }
            return lst;
        }

        public List<string> GetProducers()
        {
            List<string> lst = new List<string>();
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = sqlConnection;
                        command.CommandType = CommandType.Text;
                        command.CommandText = "SELECT producername FROM producer";
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {

                                lst.Add(Convert.ToString(reader["producername"]));

                            }
                        }
                    }
                    sqlConnection.Close();

                }
            }
            catch (Exception e)
            {

            }
            return lst;
        }

        public void InsertMovie(MovieClass movieClass)
        {
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();
                    string query = "Insert into movie values(@moviename,@plot,@dor,@actors,@producer)";
                    SqlCommand command = new SqlCommand(query, sqlConnection);
                    command.Parameters.AddWithValue("@moviename", movieClass.moviename);
                    command.Parameters.AddWithValue("@plot", movieClass.plot);
                    command.Parameters.AddWithValue("@dor", movieClass.dor);
                    command.Parameters.AddWithValue("@actors", movieClass.actors);
                    command.Parameters.AddWithValue("@producer", movieClass.producer);

                    command.ExecuteNonQuery();
                }

            }

            catch
            {

            }


        }

        public void InsertActor(ActorClass movieClass)
        {
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();
                    string query = "Insert into Actor values(@actorname,@bio,@dob,@gender)";
                    SqlCommand command = new SqlCommand(query, sqlConnection);
                    command.Parameters.AddWithValue("@actorname", movieClass.actorname);
                    command.Parameters.AddWithValue("@bio", movieClass.bio);
                    command.Parameters.AddWithValue("@dob", movieClass.dob);
                    command.Parameters.AddWithValue("@gender", movieClass.gender);

                    command.ExecuteNonQuery();
                }

            }

            catch
            {

            }


        }

        public void InsertProducer(ProducerClass movieClass)
        {
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();
                    string query = "Insert into producer values(@producername,@bio,@company,@dob,@gender)";
                    SqlCommand command = new SqlCommand(query, sqlConnection);
                    command.Parameters.AddWithValue("@producername", movieClass.producername);
                    command.Parameters.AddWithValue("@bio", movieClass.bio);
                    command.Parameters.AddWithValue("@company", movieClass.company);
                    command.Parameters.AddWithValue("@dob", movieClass.dob);
                    command.Parameters.AddWithValue("@gender", movieClass.gender);

                    command.ExecuteNonQuery();
                }

            }

            catch
            {

            }


        }
    }
}