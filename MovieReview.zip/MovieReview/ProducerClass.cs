﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MovieReview
{
    public class ProducerClass
    {
        public int producerid { get; set; }
        public string producername { get; set; }
        public string bio { get; set; }

        public string company { get; set; }
        public string dob { get; set; }
        public string gender { get; set; }
               
    }
}