﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MovieReview
{
    public partial class Movie : System.Web.UI.Page
    {
        DataBaseOperations db = new DataBaseOperations();
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                LoadGrid();
            }
        }

        private void LoadGrid()
        {
            List<MovieClass> lst = db.GetMovies();
            if(lst.Count()>0)
            {
                GridView1.DataSource = lst;
                GridView1.DataBind();
            }
        }
    }
}