﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MovieReview
{
    public partial class AddMovie : System.Web.UI.Page
    {
        DataBaseOperations db = new DataBaseOperations();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadActors();
                LoadProducers();
            }
        }
        private void LoadActors()
        {
            List<string> lst = db.GetActors();
            if(lst.Count()>0)
            {
                ListBox1.DataSource = lst;
                ListBox1.DataBind();
            }
        }
        private void LoadProducers()
        {
            List<string> lst = db.GetProducers();
            if (lst.Count() > 0)
            {
                ListBox2.DataSource = lst;
                ListBox2.DataBind();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            MovieClass movieClass = new MovieClass();
            movieClass.moviename = TextBox1.Text;
            movieClass.plot = TextBox2.Text;
            movieClass.dor = Convert.ToDateTime(TextBox3.Text);
            string actors = string.Empty;
            foreach(ListItem list in ListBox1.Items)
            {
                if (list.Selected)
                {
                    actors += list.Value.ToString() + ",";
                }
            }
            actors.TrimEnd(',');
            movieClass.actors = actors;
            movieClass.producer = ListBox2.SelectedValue.ToString();
            db.InsertMovie(movieClass);
        }
    }
}