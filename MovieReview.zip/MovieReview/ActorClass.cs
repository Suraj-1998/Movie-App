﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MovieReview
{
    public class ActorClass
    {
        public int actorid { get; set; }
        public string actorname { get; set; }
        public string bio { get; set; }
        public string dob { get; set; }
        public string gender { get; set; }
              
    }
}